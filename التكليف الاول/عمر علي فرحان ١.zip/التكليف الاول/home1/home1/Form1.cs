﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace home1
{
    public partial class Form1 : Form
    {
        Random r = new Random();
        public Form1()
        {
            InitializeComponent();
            MessageBox.Show("omar ali");
            Timer t = new Timer { Interval = 1000 };
            t.Tick += (s, e) => this.BackColor = Color.FromArgb(r.Next(256), r.Next(256), r.Next(256));
            t.Start();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }
    }
}
