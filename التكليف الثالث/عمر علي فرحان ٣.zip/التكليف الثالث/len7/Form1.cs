﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace len7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void taite_Click(object sender, EventArgs e)
        {

        }

        private void tea_Click(object sender, EventArgs e)
        {
            Tea teaDrink = new Tea();
            teaDrink.Print();
        }

        private void Malk_Click(object sender, EventArgs e)
        {
            Malk malkDrink = new Malk();
            malkDrink.Print();
        }

        private void Nescafe_Click(object sender, EventArgs e)
        {
            Nescafe nescafeDrink = new Nescafe();
            nescafeDrink.Print();
        }

        private void lemonJuice_Click(object sender, EventArgs e)
        {
            LemonJuice lemonJuiceDrink = new LemonJuice();
            lemonJuiceDrink.Print();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    public abstract class Drink
    {
        public abstract string Name { get; }
        public abstract string Price { get; }
        public abstract void Print();
    }

    public class Tea : Drink
    {
        public override string Name => "شاهي";
        public override string Price => "100 ريال";

        public override void Print()
        {
            string meg = "لصنع الشاي، اغلي الماء ثم ضع أوراق الشاي أو كيس الشاي فيه واتركه لبضع دقائق، بعد ذلك صفِّه وأضف السكر أو الحليب حسب الرغبة.";
            MessageBox.Show($"لقد قمت باختيار {Name}, وسعره {Price},\nطريقة التحضير: {meg}");
        }
    }

    public class Malk : Drink
    {
        public override string Name => "حليب عدني";
        public override string Price => "500 ريال";

        public override void Print()
        {
            string meg = "لتحضير الشاي العدني، اغلي الماء مع القليل من الشاي الأسود وأوراق النعناع والهيل، ثم أضف السكر حسب الرغبة.";
            MessageBox.Show($"لقد قمت باختيار {Name}, وسعره {Price},\nطريقة التحضير: {meg}");
        }
    }

    public class Nescafe : Drink
    {
        public override string Name => "نسكافيه";
        public override string Price => "200 ريال";

        public override void Print()
        {
            string meg = "لتحضير النسكافيه، ضع ملعقة من مسحوق النسكافيه في الكوب، أضف الماء الساخن وحرك جيداً، ثم أضف السكر والحليب حسب الرغبة.";
            MessageBox.Show($"لقد قمت باختيار {Name}, وسعره {Price},\nطريقة التحضير: {meg}");
        }
    }

    public class LemonJuice : Drink
    {
        public override string Name => "عصير ليمون";
        public override string Price => "300 ريال";

        public override void Print()
        {
            string meg = "لتحضير عصير الليمون، اعصر ليمونات طازجة، أضف الماء والسكر حسب الرغبة، ويمكن إضافة النعناع للطعم، ثم قدمه مثلجاً.";
            MessageBox.Show($"لقد قمت باختيار {Name}, وسعره {Price},\nطريقة التحضير: {meg}");
        }
    }
}