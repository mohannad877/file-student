﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int y = 1;int x = 1;
        private void Button2_Click(object sender, EventArgs e)
        {

            timer1.Start();
            timer2.Stop();
            timer3.Stop();
            timer4.Stop();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            x++;
            button1.Location = new Point(x, y);
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Start();
            timer3.Stop();
            timer4.Stop();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            timer3.Stop();
            timer4.Start();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer2.Stop();
            timer3.Start();
            timer4.Stop();
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            
            x--;
            button1.Location = new Point(x, y);
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            y--;
            button1.Location = new Point(x, y);
        }

        private void Timer4_Tick(object sender, EventArgs e)
        {
            y++;
            button1.Location = new Point(x, y);
        }
    }
}
