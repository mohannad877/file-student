﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 100; 
            timer1.Tick += Timer1_Tick;
            timer1.Start();
        }

    private void Timer1_Tick(object sender, EventArgs e)
    { int x;
            x = button1.Location.X;
            x -= 5;
            button1.Location = new Point(x, button1.Location.Y);
            if(x< -button1.Width)
            {
                button1.Location = new Point(this.Width, button1.Location.Y);
            }
    }


}
}



