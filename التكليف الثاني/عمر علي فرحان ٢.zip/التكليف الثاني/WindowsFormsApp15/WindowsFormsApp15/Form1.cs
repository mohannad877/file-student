﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp15
{
    public partial class Form1 : Form
    {
        private Timer timer;
        private string title;
        private int index;
        public Form1()
        {
            InitializeComponent();
            
       
        title = "اهلا بك في كلية العلوم والهندس في مجال تقنية المعلومات في جامعة الماليزيه الدولية تحت اشراف الدكتور جبران الحميدي له جزيل الشكر والتقدير" +
                ": ";

   
        timer = new Timer();
        timer.Interval = 100; 
        timer.Tick += Timer_Tick;
        timer.Start();
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
     
        string text = title.Substring(index) + title.Substring(0, index);
        this.Text = text;

    
        index++;
        if (index >= title.Length)
        {
            index = 0;
        }
        }
    }
}
