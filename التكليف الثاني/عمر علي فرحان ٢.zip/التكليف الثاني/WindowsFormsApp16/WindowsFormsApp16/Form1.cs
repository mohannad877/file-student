﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp16
{
    public partial class Form1 : Form
    {
        private bool isDragging = false;
        private Point offset;
        public Form1()
        {
            InitializeComponent();
            button1.MouseDown += Button_MouseDown;
            button1.MouseMove += Button_MouseMove;
            button1.MouseUp += Button_MouseUp;
        }
        private void Button_MouseDown(object sender, MouseEventArgs e)
        {
           
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                offset = new Point(e.X, e.Y);
            }
        }

        private void Button_MouseMove(object sender, MouseEventArgs e)
        {
            
            if (isDragging)
            {
                Point newLocation = new Point(e.X + button1.Left - offset.X, e.Y + button1.Top - offset.Y);
                button1.Location = newLocation;
            }
        }

        private void Button_MouseUp(object sender, MouseEventArgs e)
        {
        
            isDragging = false;
        }
    }

}