﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace تكليف_الدكتور_جبران_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar != 10 && (e.KeyChar < '0' || e.KeyChar > '9'))
            { e.Handled = false; }
            else { e.Handled = true; }
           
        }
    }
}
